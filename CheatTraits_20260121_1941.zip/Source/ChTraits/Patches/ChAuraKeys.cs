namespace ChTraits.Patches
{
    internal static class ChAuraKeys
    {
        public const string GreenThumb_Plants = "Ch.GreenThumb.Plants";
    }
}
